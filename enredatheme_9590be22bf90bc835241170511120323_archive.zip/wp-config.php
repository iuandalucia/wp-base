<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'wp_iuandalucia');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '>U7?KuB{{Mx;eMqShjW3i4|[Z;D{XEV);hqY8c?e8y/:B4eJ=e+i`8c~-(Ym.a_j');
define('SECURE_AUTH_KEY', 'vKBh#$yK:Iln;zjn%!4m~pp>+7:FZ807p*(Da5,Ip=G0a27&|5WJC&Kd6e~S7^DL');
define('LOGGED_IN_KEY', 'wa4w!*iXp*3fpn7.v8vuRQ=^lWf}?Rt8o^MYGDaZafq4op%[Z;>i-UjwC})LMNhj');
define('NONCE_KEY', 'URg|#2viPeFieBs1mDX8@Wd2{b5CmU4b4yqe)#n0dI/JrVNLHyFq#wLzf7C:$#t$');
define('AUTH_SALT', 'Tb#c?eF*X?R.0WsRvliT|58e(m#b~6{<s#wt{G>e&jXR_<R>xMV*f>^**so.5H61');
define('SECURE_AUTH_SALT', 'zEGt$T2XpmDz^-JC>qN4gFhB@D_@m3@`I@=#Va!ONa7L?XC^6g4K#i7e@2T4~7Z4');
define('LOGGED_IN_SALT', 'Qd|u;Qnz|J:~br&PlGgrX8)@nj#Qs=-{g6S@dSLMV#xV# iT#BaH{;32h`/?42iH');
define('NONCE_SALT', 'Z%/t* iQ!jtu*R5^krJjx6y;4{`FA4)ZscAQri#_[i&_nY0>_iHOm;lkMKcVp^=<');

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

